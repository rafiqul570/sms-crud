<?php
   $filepath = realpath(dirname(__FILE__)); 
   include_once $filepath.'/../class/School.php';
?>

<?php
  $school = new School();
  
   if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
     $insertAdmi = $school->insertAdmission($_POST);
}

?>

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SMS</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="../vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="../vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="../vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="../panels/css/bootstrap.css">
    <link rel="stylesheet" href="../panels/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body class="bg-dark">

    <div class="container" style="margin-top: 20px;">
      <div class="col-sm-1"></div>
      <div class="col-sm-10">

  <?php
    if (isset($insertAdmi)) {
      echo $insertAdmi;
    }

    ?> 
    <div class="panel panel-primary">
      <div class="panel-heading"><h1>Add Admission</h1>
      
        <a class="btn btn-info pull-right" href="../admin/index.php" style="margin-top: -36px;margin-right: 65px;">Back</a>
       
        
        <a class="btn btn-info pull-right" href="../admission/view.php" style="margin-top: -36px">View</a>
        
      </div>
      <div class="panel-body">
        <div class="col-sm-2"></div>
        <div class="col-sm-10">
         <form action="" method="POST" enctype="multipart/form-data">
          <div class="form-group">
            <label for="name">Name :</label>
            <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name" >
          </div>
          <div class="form-group">
            <label for="phone">Phone Number:</label>
            <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone Number" >
          </div> 
          <div class="form-group">
          <label for="image">Image:</label>
          <input type="file" class="form-control" name="image">
        </div>
         <div class="form-group">
           <button type="submit" class="btn btn-primary" name="submit">Submit</button> 
          </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <script src="../vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../panels/js/bootstrap.min.js"></script>
    <script src="../assets/js/main.js"></script>


</body>
</html>