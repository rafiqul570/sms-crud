<?php
   $filepath = realpath(dirname(__FILE__)); 
   include_once $filepath.'/../class/Student.php';
?>

<?php
    $student = new Student();
    
   if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
     $insertRes = $student->insertResult($_POST);
}

?>

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SMS</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="../vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="../vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="../vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="../panels/css/bootstrap.css">
    <link rel="stylesheet" href="../panels/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body class="<bg-">

    <div class="container" style="margin-top: 20px;">
      <div class="col-sm-1"></div>
      <div class="col-sm-10">

  <?php
    if (isset($insertRes)) {
      echo $insertRes;
    }

    ?> 
    <div class="panel panel-primary">
      <div class="panel-heading"><h1>Add Result</h1>
      
        <a class="btn btn-info pull-right" href="../admin/index.php" style="margin-top: -36px;margin-right: 65px;">Back</a>
       
        
        <a class="btn btn-info pull-right" href="check_roll.php" style="margin-top: -36px">View</a>
        
      </div>
      <div class="panel-body">
        <div class="col-sm-1"></div>
        <div class="col-sm-10">
         <form action="" method="POST">
             <table class="table table-bordered table-striped">
            <tr>
              <th>Name</th>
              <td><input style="width: 100%" type="text" name="name" placeholder="Name"></td>
              <th>Roll</th>
              <td><input style="width: 100%" type="text" name="roll" placeholder="Roll"></td>
            </tr>
            
            <tr>
              <th>Class</th>
              <td><input style="width: 100%" type="text" name="class" placeholder="Class"></td>
              <th>Year</th>
              <td><input style="width: 100%" type="text" name="year" placeholder="Year"></td>
            </tr>
          </table>
          <table class="table table-bordered table-striped">
            <tr>
              <th width="130">Bangla</th>
              <td><input style="width: 100%" type="text" name="ban" placeholder="Bamgla Mark"></td>
            </tr>
            <tr>
              <th>English</th>
              <td><input style="width: 100%" type="text" name="eng" placeholder="English Mark"></td>
            </tr>
            <tr>
              <th>Math</th>
              <td><input style="width: 100%" type="text" name="math" placeholder="Math Mark"></td>
            </tr>
            <tr>
              <th>Agriculture</th>
              <td><input style="width: 100%" type="text" name="ag" placeholder="Agriculture Mark"></td>
            </tr>
            </tr>
            </table>
            <input class="btn btn-primary" type="submit" name="submit" value="Save">
          </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="../vendors/jquery/dist/jquery.min.js"></script>
  <script src="../vendors/popper.js/dist/umd/popper.min.js"></script>
  <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="../panels/js/bootstrap.min.js"></script>
  <script src="../assets/js/main.js"></script>


</body>
</html>