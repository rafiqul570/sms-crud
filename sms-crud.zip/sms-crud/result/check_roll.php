<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SMS</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="../vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="../vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="../vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="../panels/css/bootstrap.css">
    <link rel="stylesheet" href="../panels/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body class="<bg-">

    <div class="container" style="margin-top: 20px;">
      <div class="col-sm-1"></div>
      <div class="col-sm-10">

    <div class="panel panel-primary">
      <div class="panel-heading"><h1>Add Result</h1>
      
        <a class="btn btn-info pull-right" href="../admin/index.php" style="margin-top: -36px;margin-right: 65px;">Back</a>
       
        
        <a class="btn btn-info pull-right" href="view.php" style="margin-top: -36px">View</a>
        
      </div>
      <div class="panel-body">
        <div class="col-sm-1"></div>
        <div class="col-sm-10">
         <form action="view.php" method="POST">
             <table class="table table-bordered table-striped">
            <tr>
              <th>Roll</th>
              <td><input style="width: 100%" type="text" name="roll" placeholder="Roll" required=""></td>
            </tr>
            
            <tr>
              <th>Class</th>
              <td><input style="width: 100%" type="text" name="class" placeholder="Class" required=""></td>
            </tr>
             <tr>
              <th>Year</th>
              <td><input style="width: 100%" type="text" name="year" placeholder="Year" required=""></td>
            </tr>
          </table>
          <input class="btn btn-primary" type="submit" name="submit" value="Save">
          </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="../vendors/jquery/dist/jquery.min.js"></script>
  <script src="../vendors/popper.js/dist/umd/popper.min.js"></script>
  <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="../panels/js/bootstrap.min.js"></script>
  <script src="../assets/js/main.js"></script>


</body>
</html>