<?php 
include('../lib/connect.php');
if(isset($_POST['class'])){
$class = $_POST['class'];   
$roll = $_POST['roll'];
$year = $_POST['year'];
$con = connectBD();
$sql = "SELECT * from result WHERE class = '$class' AND roll = '$roll' 
AND year = '$year'";
 $result = mysqli_query($con,$sql);
 $rowcount = mysqli_num_rows($result);
 ?>

<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SMS</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="../apple-icon.png">
    <link rel="shortcut icon" href="../favicon.ico">


    <link rel="stylesheet" href="../vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="../vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="../vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="../vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="../vendors/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">

    <link rel="stylesheet" href="../assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
</head>

<body>

    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="../admin/index.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
           
        </nav>
</aside><!-- /#left-panel -->

<!-- Left Panel -->

<!-- Right Panel -->

 <div id="right-panel" class="right-panel">

    <!-- Header-->
    <header id="header" class="header">

        <div class="header-menu">

            <div class="col-sm-7">
                <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                <div class="header-left">
                    <button class="search-trigger"><i class="fa fa-search"></i></button>
                    <div class="form-inline">
                        <form class="search-form">
                            <input class="form-control mr-sm-2" type="text" placeholder="Search ..." aria-label="Search">
                            <button class="search-close" type="submit"><i class="fa fa-close"></i></button>
                        </form>
                    </div>

                   
                </div>
            </div>

            <div class="col-sm-5">
               
            </div>
        </div>

    </header><!-- /header -->
    <!-- Header-->

    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                
                <div class="col-md-12">
                    <div class="card">
                    <div class="card-header">
                        <?php if($rowcount == 1){

                        } else{

                          echo '<div class="alert alert-danger alert-dismissible">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                 <strong>Warning !</strong> wrong Roll number or Class name please try again!
                                </div>';
                        } ?>

                        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                        <strong class="card-title"><h3>RESULT SHEET</h3></strong>
                        <a class="btn btn-info pull-right" href="create.php" style="margin-top: -36px">Add</a>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                        
                        
                             <tr>
                                <th>Name</th>
                                <td><?php echo $row['name'];?></td>
                                <th>Class</th>
                                <td><?php echo $row['class'];?></td>
                            </tr>
                            <tr>
                                <th>Roll</th>
                                <td><?php echo $row['roll'];?></td>
                                <th>Year</th>
                                <td><?php echo $row['year'];?></td>
                             </tr>
                             <tr>
                                <th>Total Marks</th>
                                <td><?php echo $row['obtmark'];?></td>
                                <th>GPA/Result</th>
                                <td><?php echo $row['total_gpa2'];?><h4 style="color: red;margin-top: -23px;padding-left: 60px;"><?php echo $row['result']; ?></h4></td>
                             </tr>
                            </table>
                            <h6 style="text-align: center;color: green;font-size: 30px;">Mark sheet</h6>  
                            <table style="margin-top: 30px" class="table table-bordered table-striped">
                                <tr style="color: green;text-align: center;">
                                    <th>Sl.No.</th>
                                    <th>Name of Subjects</th>
                                    <th>Marks</th>
                                    <th>Letter Grade</th>
                                    <th>Grade Point</th>
                                    <th width="150">GPA<p style="font-size: 10px;">(without additional subject)</p></th>
                                    <th width="100" align="center">GPA</th>
                                </tr>
                                <tr>
                                    <td>1</td>
                                    <td>Bangla</td>
                                    <td><?php echo $row['ban'];?></td>
                                    <td><?php echo $row['gr_ban'];?></td>
                                    <td><?php echo $row['gpa_ban'];?></td>
                                    <td rowspan="4" style="padding-top: 90px; text-align: center;">
                                        <?php echo $row['total_gpa1'];?></td>
                                    <td rowspan="6" style="padding-top: 90px; text-align: center;">
                                        <?php echo $row['total_gpa2'];?></td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>English</td>
                                    <td><?php echo $row['eng'];?></td>
                                    <td><?php echo $row['gr_eng'];?></td>
                                    <td><?php echo $row['gpa_eng'];?></td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>Math</td>
                                    <td><?php echo $row['math'];?></td>
                                    <td><?php echo $row['gr_math'];?></td>
                                    <td><?php echo $row['gpa_math'];?></td>
                                </tr>
                                <tr>
                                    <td colspan="5" style="color: green">Additional Subject :</td>
                                    
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>Agriculture Studies</td>
                                    <td><?php echo $row['ag'];?></td>
                                    <td><?php echo $row['gr_ag'];?></td>
                                    <td><?php echo $row['gpa_ag'];?></td>
                                    <td align="center"><span style="color: green">(GP above 2)</span><br>
                                        <?php echo $row['gpa_2_ag'];?></td>
                                </tr>
                                <!-- <tr>
                                    <td colspan="3"> <h4 style="">Total Marks = 
                                        <?php echo $row['obtmark'];?></h4></td>
                                    <td colspan="6" style="text-align: center;color: red;font-size: 20px;">
                                        <?php echo $row['result']; ?></td>
                                </tr> -->
                             
                            </table>
                        <?php } } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- .animated -->
    </div><!-- .content -->


</div><!-- /#right-panel -->

<!-- Right Panel -->


<script src="../vendors/jquery/dist/jquery.min.js"></script>
<script src="../vendors/popper.js/dist/umd/popper.min.js"></script>
<script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="../assets/js/main.js"></script>


<script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="../vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="../vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
<script src="../vendors/jszip/dist/jszip.min.js"></script>
<script src="../vendors/pdfmake/build/pdfmake.min.js"></script>
<script src="../vendors/pdfmake/build/vfs_fonts.js"></script>
<script src="../vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="../vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="../vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
<script src="../assets/js/init-scripts/data-table/datatables-init.js"></script>


</body>

</html>
