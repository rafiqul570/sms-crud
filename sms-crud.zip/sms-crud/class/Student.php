<?php
   $filepath = realpath(dirname(__FILE__)); 
   include_once $filepath.'/../lib/dboop.php';
?>


<?php
class Student{
  
  private $db;

  public function __construct(){
    $this->db = new Connect();
  }


 public function getStudentData(){
    $query = "SELECT *FROM student";
    $result = $this->db->select($query);
    return $result; 
  }


 public function insertStudent($name, $roll){
  $name = mysqli_real_escape_string($this->db->link, $name);
  $roll = mysqli_real_escape_string($this->db->link, $roll);
  if (empty($name) || empty($roll)) {
          
          $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Error !</strong> Field must not be Empty !
            </div>';
    
          return $msg; 
      }else{

        $query = "INSERT INTO student(name,roll) VALUES('$name','$roll')";
        $result = $this->db->insert($query);
        

        $query = "INSERT INTO attendence(roll) VALUES('$roll')";
        $result = $this->db->insert($query);
        

        if ($result) {

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Success !</strong>  Data Inserte Successfully.
            </div>';
  
       return $msg;
     
       
   }else{

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Error !</strong>  Sorry, Data Not Inserted.
            </div>';
  
       return $msg; 
       } 
      }
  
  }

  public function insertAttendence($cur_date, $attend = array()){

          $query = "SELECT DISTINCT att_time FROM attendence";
          $getdata = $this->db->select($query);
          while($row = $getdata->fetch_assoc()){
            $db_date = $row['att_time'];
            $result = ($cur_date == $db_date);
            if ($result) {
                $msg = '<div class="alert alert-danger alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Error !</strong>  Attendence already taken today.
                </div>';
    
               return $msg; 
            
          }
  
     }
   foreach ($attend as $atn_key => $atn_value) {
        
         if ($atn_value == "present") {
             
             $query ="INSERT INTO attendence(roll, attend, att_time)VALUES('$atn_key','present',now())";
               $result = $this->db->insert($query);
         
         }elseif($atn_value == "absent") {
             
             $query ="INSERT INTO attendence(roll, attend, att_time)VALUES('$atn_key','absent',now())";
               $result = $this->db->insert($query);

         
       }

      }

        if ($result) {

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Success !</strong> Attendence data Inserte Successfully.
            </div>';
  
       return $msg;
     
       
   }else{

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Error !</strong> Attendence data Not Inserted.
            </div>';
  
       return $msg; 
       } 
      }

   public function getDateList(){
            
            $query = "SELECT DISTINCT att_time FROM attendence";
            $result = $this->db->select($query);
            return $result;

      }

   public function getAllData($dt){

            $query = "SELECT student.name, attendence.*FROM student INNER JOIN attendence ON student.roll = attendence.roll WHERE att_time = '$dt'";
              $result = $this->db->select($query);
              return $result;
      }

      public function updateAttendence($dt, $attend){

         foreach ($attend as $atn_key => $atn_value) {
              if ($atn_value == "present") {
             $query = "UPDATE attendence SET attend = 'present' WHERE roll = '".$atn_key."' AND att_time = '".$dt."'";
              $result = $this->db->update($query);
             
         
         }elseif($atn_value == "absent") {
             
             $query = "UPDATE attendence SET attend = 'absent' WHERE roll = '".$atn_key."' AND att_time = '".$dt."'";
              $result = $this->db->update($query);

         
       }

      }

        if ($result) {

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Success !</strong> Attendence Update Successfully.
            </div>';
  
       return $msg;
     
       
   }else{

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Error !</strong> Attendence Not Updated.
            </div>';
  
       return $msg; 
       } 

      }


 //===================RESULT PART===================
     public function insertResult($data){
            $name  = $data['name'];
            $class = $data['class'];
            $roll  = $data['roll'];
            $year  = $data['year'];
            $ban   = $data['ban'];
            $eng   = $data['eng'];
            $math  = $data['math'];
            $ag    = $data['ag'];
   if ($name == "" OR $class == "" OR $roll == "" OR $year == "" OR $ban == "" OR $eng == "" OR $math == "" OR $ag == ""  ) {
        
  $msg = '<div class="alert alert-danger alert-dismissible">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
           <strong>Error !</strong> Field must not be Empty !
          </div>';
  
       return $msg; 
   
 }



  //Bangla
  if(($ban>=80)&&($ban<=100)){
    (($gr_ban = "A+")&&
    ($gpa_ban = 5.0));
  }else if(($ban>=70)&&($ban<=79.99)){
    (($gr_ban = "A")&&
    ($gpa_ban = "4.0"));
  }else if(($ban>=60)&&($ban<=69.99)){
    (($gr_ban = "A-")&&
    ($gpa_ban = "3.5"));
  }else if(($ban>=50)&&($ban<=59.99)){
    (($gr_ban = "B")&&
    ($gpa_ban = "3.0"));
  }else if(($ban>=40)&&($ban<=49.99)){
    (($gr_ban = "C")&&
    ($gpa_ban = "2.0"));
  }else if(($ban>=33)&&($ban<=39.99)){
    (($gr_ban = "D")&&
    ($gpa_ban = "1.0"));
  }else{
    (($gr_ban = "F")&&
    ($gpa_ban = "0.0"));
  }

  //English
  if(($eng>=80)&&($eng<=100)){
    (($gr_eng = "A+")&&
    ($gpa_eng = "5.0"));
  }else if(($eng>=70)&&($eng<=79.99)){
    (($gr_eng = "A")&&
    ($gpa_eng = "4.0"));
  }else if(($eng>=60)&&($eng<=69.99)){
    (($gr_eng = "A-")&&
    ($gpa_eng = "3.5"));
  }else if(($eng>=50)&&($eng<=59.99)){
    (($gr_eng = "B")&&
    ($gpa_eng = "3.0"));
  }else if(($eng>=40)&&($eng<=49.99)){
    (($gr_eng = "C")&&
    ($gpa_eng = "2.0"));
  }else if(($eng>=33)&&($eng<=39.99)){
    (($gr_eng = "D")&&
    ($gpa_eng = "1.0"));
  }else{
    (($gr_eng = "F")&&
    ($gpa_eng = "0.0"));
  }
  //Math
  if(($math>=80)&&($math<=100)){
    (($gr_math = "A+")&&
    ($gpa_math = "5.0"));
  }else if(($math>=70)&&($math<=79.99)){
    (($gr_math = "A")&&
    ($gpa_math = "4.0"));
  }else if(($math>=60)&&($math<=69.99)){
     (($gr_math = "A-")&&
     ($gpa_math = "3.5"));
  }else if(($math>=50)&&($math<=59.99)){
    (($gr_math = "B")&&
    ($gpa_math = "3.0"));
  }else if(($math>=40)&&($math<=49.99)){
    (($gr_math = "C")&&
    ($gpa_math = "2.0"));
  }else if(($math>=33)&&($math<=39.99)){
    (($gr_math = "D")&&
    ($gpa_math = "1.0"));
  }else{
    (($gr_math = "F")&&
    ($gpa_math = "0.0"));
  }
  //Agriculture
  if(($ag>=80)&&($ag<=100)){
    (($gr_ag = "A+")&&
    ($gpa_ag = "5.0"));
  }else if(($ag>=70)&&($ag<=79.99)){
    (($gr_ag = "A")&&
    ($gpa_ag = "4.0"));
  }else if(($ag>=60)&&($ag<=69.99)){
    (($gr_ag = "A-")&&
    ($gpa_ag = "3.5"));
  }else if(($ag>=50)&&($ag<=59.99)){
    (($gr_ag = "B")&&
    ($gpa_ag = "3.0"));
  } else if(($ag>=40)&&($ag<=49.99)){
    (($gr_ag = "C")&&
    ($gpa_ag = "2.0"));
  }else if(($ag>=33)&&($ag<=39.99)){
    (($gr_ag = "D")&&
    ($gpa_ag = "1.0"));
  }else{
    (($gr_ag = "F")&&
    ($gpa_ag = "0.0"));
  }


  //Addtional subject-gpa(Gp above 2)
  if(($ag>=80)&&($ag<=100)){
    $gpa_2_ag = "3.00";
  }else if(($ag>=70)&&($ag<=79.99)){
    $gpa_2_ag = "2";
  }else if(($ag>=60)&&($ag<=69.99)){
    $gpa_2_ag = "1.5";
  }else if(($ag>=50)&&($ag<=59.99)){
    $gpa_2_ag = "1.00";
  }else{
    $gpa_2_ag = "0.00";
  }


  //total marks
  $obtmark = $ban+$eng+$math+$ag;

  //without Additional Subject
   $total_gpa1 = ($gpa_ban+$gpa_eng+$gpa_math)/3;
  //with Additional Subject
   $total_gpa2 = ($gpa_ban+$gpa_eng+$gpa_math+$gpa_2_ag)/3;
   
  //Condition

  if(($total_gpa2)>=5){

      $total_gpa2 = "5.00";
  }
  //result pass/fail
  if($ban <=32 OR $eng <=32 OR $math<=32){
    $result = "Fail";

  }else{

    $result = " ";
  }


  $query = "INSERT INTO result VALUES(NULL,'$name','$class','$roll','$year','$ban',
  '$gr_ban','$gpa_ban','$eng','$gr_eng','$gpa_eng','$math','$gr_math','$gpa_math',
  '$ag','$gr_ag','$gpa_ag','$gpa_2_ag','$obtmark','$total_gpa1','$total_gpa2',
  '$result');";
  $result = $this->db->insert($query);

  if ($result) {

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Success !</strong> Result data Inserte Successfully.
            </div>';
  
       return $msg;
     
       
   }else{

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Error !</strong> Result data Not Inserted.
            </div>';
  
       return $msg; 
       } 
      

      }

   
     

        public function checkResult($class, $roll, $year){
               $class = $_POST['class'];
               $roll  = $_POST['roll'];
               $year  = $_POST['year'];

               if ($class == "" OR $roll == "" OR $year == "" ) {
        
              $msg = '<div class="alert alert-danger alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                 <strong>Error !</strong> Field must not be Empty !
                </div>';
        
             return $msg; 
   
 }


    $query = "SELECT * FROM result WHERE class = '$class' AND roll = '$roll' AND year = '$year'";
          $result = $this->db->select($query);
          $rowcount = mysqli_num_rows($result);
            if($rowcount == 1){
              header('Location: view.php');
            }else{
                $msg = '<div class="alert alert-danger alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                 <strong>Warning !</strong> wrong Roll number or Class name please try again!
                </div>';
  
                 return $msg; 
            }
          
          

        //   public function getResultData(){

        //   $query = "SELECT * FROM result ORDER BY id DESC";
        //   $result = $this->db->select($query);
        //   return $result;

        // }
       }   

  } 
  
?>