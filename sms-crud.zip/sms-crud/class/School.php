<?php
   $filepath = realpath(dirname(__FILE__)); 
   include_once $filepath.'/../lib/Database.php';
    include_once $filepath.'/../class/Session.php';
?>

<?php
class School{

	private $db;

	public function __construct(){
		$this->db = new Database();
		
    }
    
    //Insert Notice
  public function insertNotice($data){
  	     $date    = $data['date'];
		 $subject = $data['subject'];
		
		 $file_name = $_FILES['file']['name'];
		 $file_size = $_FILES['file']['size'];
		 $file_type = $_FILES['file']['type'];
		 $tmp_name  = $_FILES['file']['tmp_name'];
		 $permited  = array('pdf');
		 $div = explode(".", $file_name);
	 	 $file_ext = strtolower(end($div));
	 	 $file_check = in_array($file_ext, $permited);
	 	 $file = uniqid().$file_ext;
		 $uploaded_file = '../uploads/file/'.$file;
		 
		 

      

      if ($date == "" OR $subject == "" ) {
		    	
    	$msg = '<div class="alert alert-danger alert-dismissible">
		        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		         <strong>Error !</strong> Field must not be Empty !
		        </div>';
		
	       return $msg; 
		 
	 }

	 if (empty($file_name)) {
	 	$msg = '<div class="alert alert-danger alert-dismissible">
	 	        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		         <strong>Please !</strong> Select any File .
	 	        </div>';
		
	        return $msg; 
	
		 
	 }elseif($file_size > 304803456){

	 	$msg = '<div class="alert alert-danger alert-dismissible">
	 	        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		         <strong>Error !</strong> Image size should be less then 3KB
	 	        </div>';
		
	        return $msg; 

	 }elseif($file_check === false) {
	 	
	 			
				$msg = '<div class="alert alert-danger alert-dismissible">
	  	        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		         <strong>Sorry !</strong>You can upload only  - pdf		        </div>';
	
	    return $msg;  
	  
	  }else{
 		
	 move_uploaded_file($tmp_name,  $uploaded_file);

	 $sql="INSERT INTO uploads(date,subject,file) VALUES(:date, :subject, :file)";
		$query = $this->db->pdo->prepare($sql);
		$query->bindValue(':file', $file);
		$query->bindValue(':date', $date);
		$query->bindValue(':subject', $subject);
		$result = $query->execute();

	if ($result) {
			
	    $msg = '<div class="alert alert-danger alert-dismissible">
		        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		         <strong>Success !</strong>  Data Inserted Successfully.
		        </div>';

        return $msg;
		   
	}else{

 		$msg = '<div class="alert alert-danger alert-dismissible">
		        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		         <strong>Error !</strong>  Sorry, Data Not Inserted.
		        </div>';
		
	     return $msg;  
	
	}
   
   }	

  } 
// Select Notice
  public function getNoticeData(){

		$sql = "SELECT * FROM uploads ORDER BY id DESC";
		$query = $this->db->pdo->prepare($sql);
		$query->execute();
		$result = $query->fetchAll();
		return $result;

 }

//Update Notice
 
  public function getNoticeById($id){
 	$sql = "SELECT * FROM uploads WHERE id = :id LIMIT 1";
 	$query = $this->db->pdo->prepare($sql);
 	$query->bindValue(':id', $id);
	$query->execute();
	$result = $query->fetch(PDO::FETCH_OBJ);
	return $result;
 }

   public function updateNotice($id, $data){

	 	$date = $data['date'];
		$subject = $data['subject'];
	

	$sql = "UPDATE uploads set date = :date, subject = :subject 
	 WHERE id = :id";

			$query = $this->db->pdo->prepare($sql);
			$query->bindValue(':date', $date);
			$query->bindValue(':subject', $subject);
			$query->bindValue(':id', $id);
			$result = $query->execute();

			if ($result) {
		
			    $msg = '<div class="alert alert-danger alert-dismissible">
			        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			         <strong>Error !</strong> Data Updated Successfully.
			        </div>';
			
		       return $msg; 
	   
	
	}else{

		$msg = '<div class="alert alert-danger alert-dismissible">
			        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			         <strong>Error !</strong> Data Not Updated.
			        </div>';
			
		       return $msg; 
	
	}
	

  } 
   
//Delete Notice  
	public function deleteNotice($id){

			$img = "SELECT * FROM uploads WHERE id = $id";
            $q = $this->db->pdo->prepare($img);
            $q->execute();
            $row = $q->fetch();

            $sql = "DELETE FROM uploads WHERE id = :id";
            $query = $this->db->pdo->prepare($sql);
            $query->bindParam(':id', $id, PDO::PARAM_INT);
            $result = $query->execute();   
            $file = $row['file'];
            unlink("../uploads/file/".$file);
           

        if ($result){
        	$msg = '<div class="alert alert-danger alert-dismissible">
			        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			         <strong>Success !</strong> Data Delete Successfully.
			        </div>';
			
		       return $msg; 
		      
	   
		}else{

			$msg = '<div class="alert alert-danger alert-dismissible">
				        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				         <strong>Error !</strong> Data Not Deleted.
				        </div>';
				
			       return $msg; 
		
		}
		
        }

 //============== ADMISSION PART ==================
   

   
 //Insert Admission
    public function insertAdmission($data){
		$name = $data['name'];
		$phone = $data['phone'];

	    $file_name = $_FILES['image']['name'];
	    $file_size = $_FILES['image']['size'];
	 	$tmp_name  = $_FILES['image']['tmp_name'];
	 	
	 	$permited  = array('jpeg', 'jpg', 'png', 'gif');
	 	$div = explode(".", $file_name);
	 	$file_ext = strtolower(end($div));
	 	$file_check = in_array($file_ext, $permited);
	 	$image = uniqid().$file_ext;
	 	$uploaded_image = '../uploads/image/'.$image;
	 		
	 
	
  
  if ($name == "" OR $phone == "" ) {
		    	
    	$msg = '<div class="alert alert-danger alert-dismissible">
	 	        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		         <strong>Error !</strong> Field must not be Empty !
	 	        </div>';
		
	        return $msg; 
	    }
	
	if (empty($file_name)){
		$msg = '<div class="alert alert-danger alert-dismissible">
	 	        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		         <strong>Sorry !</strong> Please Select any Image .
	 	        </div>';
		
	        return $msg; 
	
		 
	 }elseif($file_size > 304803456){

	 	$msg = '<div class="alert alert-danger alert-dismissible">
	 	        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		         <strong>Error !</strong> Image size should be less then 3KB
	 	        </div>';
		
	        return $msg; 

	 }elseif($file_check === false) {
	 	
	 			
				$msg = '<div class="alert alert-danger alert-dismissible">
	  	        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		         <strong>Sorry !</strong>You can upload only  -  ( jpeg, jpg, png, gif )
		        </div>';
	
	    return $msg;  
	  
	  }else{
 		
   move_uploaded_file($tmp_name, $uploaded_image);

  $sql = "INSERT INTO admission (name,phone,image) VALUES (:name, :phone, :image)";
		$query = $this->db->pdo->prepare($sql);
		$query->bindParam(':name', $name);
		$query->bindParam(':phone', $phone);
		$query->bindParam(':image', $image);
	    $result = $query->execute();

	 if ($result) {

	 	$msg = '<div class="alert alert-danger alert-dismissible">
	 	        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	 	         <strong>Success !</strong>  Data Inserte Successfully.
	 	        </div>';
	
       return $msg;
	   
		   
	 }else{

	 	$msg = '<div class="alert alert-danger alert-dismissible">
	 	        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	 	         <strong>Error !</strong>  Sorry, Data Not Inserted.
	 	        </div>';
	
	     return $msg; 
	     } 

      }
    
   }
  //Select data in index page (Admission) 
     public function getAdmissionData(){

		$sql = "SELECT * FROM admission ORDER BY id DESC";
		$query = $this->db->pdo->prepare($sql);
		$query->execute();
		$result = $query->fetchAll();
		return $result;

 }

//Select data in Update page (Admission)
 
    public function getAdmissionById($id){
	 	$sql = "SELECT * FROM admission WHERE id = :id LIMIT 1";
	 	$query = $this->db->pdo->prepare($sql);
	 	$query->bindParam(':id', $id);
		$query->execute();
		$result = $query->fetch(PDO::FETCH_OBJ);
		return $result;
	 }

//Update Image/Data
   public function updateAdmission($id, $data){
     	
     	$img = "SELECT * FROM admission WHERE id = $id";
        $q = $this->db->pdo->prepare($img);
        $q->execute();
        $row = $q->fetch();
        
        $name = $data['name'];
	    $phone = $data['phone'];
	    
	    $img = $_FILES['image'];
	 	$tmp_name = $img['tmp_name'];
	 	$image = uniqid().$_FILES['image']['name'];
	 	$fileName = '../uploads/image/'.$image;
	 	if ($img['size'] > 1) {
	 		if (file_exists("../uploads/image/".$row['image']) && !empty($row['image'])) {
	 			unlink("../uploads/image/".$row['image']);
	 		}

	 		move_uploaded_file($tmp_name, $fileName);


$sql = "UPDATE admission set name = :name, phone = :phone, image = :image WHERE id = :id";

		$query = $this->db->pdo->prepare($sql);
		$query->bindParam(':name', $name);
		$query->bindParam(':phone', $phone);
		$query->bindParam(':image', $image);
		$query->bindParam(':id', $id,);
	 	

	 	}else{
	 	
	 


$sql = "UPDATE admission set name = :name, phone = :phone WHERE id = :id";

		$query = $this->db->pdo->prepare($sql);
		$query->bindParam(':name', $name);
		$query->bindParam(':phone', $phone);
		$query->bindParam(':id', $id,);
	  
	 }
		
		$result = $query->execute();

		if ($result) {
	
		    $msg = '<div class="alert alert-danger alert-dismissible">
		        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		         <strong>Error !</strong> Data Update Successfully.
		        </div>';
		
	       return $msg; 
   

	}else{

		$msg = '<div class="alert alert-danger alert-dismissible">
			        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			         <strong>Error !</strong> Data Not Updated.
			        </div>';
			
		       return $msg; 
	
	}
	 
 

  } 
//Delete Admission  
  public function deleteAdmission($id){
  			
		    $img = "SELECT * FROM admission WHERE id = $id";
            $q = $this->db->pdo->prepare($img);
            $q->execute();
            $row = $q->fetch();

            $sql = "DELETE FROM admission WHERE id = :id";
            $query = $this->db->pdo->prepare($sql);
            $query->bindParam(':id', $id, PDO::PARAM_INT);
            $result = $query->execute();   
            $image = $row['image'];
            unlink("../uploads/image/".$image);
           

        if ($result){
        	$msg = '<div class="alert alert-danger alert-dismissible">
			        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			         <strong>Success !</strong> Data Delete Successfully.
			        </div>';
			
		       return $msg; 
		      
	   
		}else{

			$msg = '<div class="alert alert-danger alert-dismissible">
				        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				         <strong>Error !</strong> Data Not Deleted.
				        </div>';
				
			       return $msg; 
		
		}
		
        }


}

?>
	