-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2021 at 10:47 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `username`, `email`, `password`) VALUES
(1, 'Rafiqul Islam', 'rafiqul', 'rafiqul.master5@gmail.com', 'e10adc3949ba59abbe56e057f20f883e'),
(2, 'Mala khandokat', 'mala', 'mala@gmail.com', 'e10adc3949ba59abbe56e057f20f883e');

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE `admission` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `image` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admission`
--

INSERT INTO `admission` (`id`, `name`, `phone`, `image`) VALUES
(284, 'Rafiqul Islam', '01721853793', '60a849a1d28eapng'),
(285, 'Rafiqul Islam', '01721853793', '60a849ad5fad7jpg'),
(286, 'Advanced Plugin', '01720803590', '60a849baca7dejpg');

-- --------------------------------------------------------

--
-- Table structure for table `attendence`
--

CREATE TABLE `attendence` (
  `id` int(11) NOT NULL,
  `roll` int(11) NOT NULL,
  `attend` varchar(200) NOT NULL,
  `att_time` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendence`
--

INSERT INTO `attendence` (`id`, `roll`, `attend`, `att_time`) VALUES
(119, 101, 'present', '2021-05-18'),
(120, 102, 'present', '2021-05-18'),
(121, 103, 'absent', '2021-05-18'),
(122, 104, 'absent', '2021-05-18');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `class` varchar(100) NOT NULL,
  `roll` varchar(100) NOT NULL,
  `year` varchar(100) NOT NULL,
  `ban` int(11) NOT NULL,
  `gr_ban` varchar(20) NOT NULL,
  `gpa_ban` double DEFAULT NULL,
  `eng` int(11) NOT NULL,
  `gr_eng` varchar(20) NOT NULL,
  `gpa_eng` double NOT NULL,
  `math` int(11) NOT NULL,
  `gr_math` varchar(20) NOT NULL,
  `gpa_math` double NOT NULL,
  `ag` int(11) NOT NULL,
  `gr_ag` varchar(20) NOT NULL,
  `gpa_ag` double NOT NULL,
  `gpa_2_ag` double NOT NULL,
  `obtmark` int(11) NOT NULL,
  `total_gpa1` double(20,2) DEFAULT NULL,
  `total_gpa2` double(20,2) NOT NULL,
  `results` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`id`, `name`, `class`, `roll`, `year`, `ban`, `gr_ban`, `gpa_ban`, `eng`, `gr_eng`, `gpa_eng`, `math`, `gr_math`, `gpa_math`, `ag`, `gr_ag`, `gpa_ag`, `gpa_2_ag`, `obtmark`, `total_gpa1`, `total_gpa2`, `results`) VALUES
(78, 'Rafiqul Islam', 'eight', '104', '2021', 60, 'A-', 3.5, 80, 'A+', 5, 80, 'A+', 5, 80, 'A+', 5, 3, 300, 4.50, 5.00, ' '),
(79, 'Rafiqul Islam', 'eight', '104', '2021', 60, 'A-', 3.5, 80, 'A+', 5, 80, 'A+', 5, 80, 'A+', 5, 3, 300, 4.50, 5.00, ' '),
(80, 'Rafiqul Islam', 'eight', '104', '2021', 30, 'F', 0, 80, 'A+', 5, 80, 'A+', 5, 80, 'A+', 5, 3, 270, 3.33, 4.33, 'Fail');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `roll` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `roll`) VALUES
(27, 'Rafiqul Islam', '101'),
(28, 'Rafiqul Islam sk', '102'),
(29, 'mainul', '103'),
(30, 'Naim', '104');

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE `uploads` (
  `id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `uploads`
--

INSERT INTO `uploads` (`id`, `subject`, `file`, `date`) VALUES
(104, 'Kachua muktijodda', '60a3b63e1bdbbpdf', '2021-05-18'),
(105, 'Kachua Moghia', '60a3bbfe6dab0pdf', '2021-05-19'),
(106, 'Kachua Moghia', '60a457824f130pdf', '2021-05-20');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`) VALUES
(6, 'Mala khandokat', 'mala', 'mala@gmail.com', 'e10adc3949ba59abbe56e057f20f883e'),
(7, 'Mala khandokat', 'mala', 'mala@gmail.com', 'e10adc3949ba59abbe56e057f20f883e'),
(8, 'Mala khandokat', 'mala', 'mala@gmail.com', 'e10adc3949ba59abbe56e057f20f883e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admission`
--
ALTER TABLE `admission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendence`
--
ALTER TABLE `attendence`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admission`
--
ALTER TABLE `admission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=287;

--
-- AUTO_INCREMENT for table `attendence`
--
ALTER TABLE `attendence`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
